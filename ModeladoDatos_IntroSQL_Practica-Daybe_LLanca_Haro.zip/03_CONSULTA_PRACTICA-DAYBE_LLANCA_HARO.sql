select
	g.nombre_grupo as grupo,
	mc.nombre_marca as marca,
	md.nombre_modelo as modelo,
	c.id_matricula_coche as matricula,
	date(c.fecha_compra_coche) as fecha_compra,
	cr.nombre_color as color,
	c.km_actual_coche as kilometraje,
	ca.nombre_cia_aseguradora as compania_aseguradora,
    cp.id_contrato_poliza as numero_poliza,
    r.mecanico_revision as mecanico_ult_rev,
    r.km_revision as km_ult_rev,
    r.importe_revision as importe_ult_rev,
    d.acronimo_divisa as divisa_ult_rev,
    d.tipo_cambio_a_eur_divisa * r.importe_revision  as importe_ult_rev_EUR
from kc_coches.coche c 
left outer join kc_coches.modelo md 
on c.id_modelo = md.id_modelo 
left outer join kc_coches.marca mc
on md.id_marca = mc.id_marca 
left outer join kc_coches.grupo g 
on g.id_grupo = mc.id_grupo
left outer join kc_coches.color cr
on cr.id_color = c.id_color
left outer join kc_coches.contrato_poliza cp  
on cp.id_contrato_poliza = c.id_contrato_poliza 
left outer join kc_coches.compania_aseguradora ca 
on ca.id_cia_aseguradora = cp.id_cia_aseguradora 
left outer join 
(
	select 
		id_matricula_coche as matricula,
		max(id_revision) as id_revision_max
	from kc_coches.revision rev
	left outer join kc_coches.divisa d 
	on rev.id_divisa = d.id_divisa 
	group by id_matricula_coche 	
) ultima_rev 
on ultima_rev.matricula = c.id_matricula_coche 
left outer join kc_coches.revision r 
on r.id_revision = ultima_rev.id_revision_max
left outer join kc_coches.divisa d
on r.id_divisa = d.id_divisa 
where c.estado_coche = true
order by grupo, marca, modelo, matricula