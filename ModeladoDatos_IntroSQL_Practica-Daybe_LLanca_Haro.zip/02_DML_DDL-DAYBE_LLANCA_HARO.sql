create schema kc_coches;

CREATE TABLE kc_coches.compania_aseguradora (
	id_cia_aseguradora serial NOT NULL,
	nombre_cia_aseguradora varchar(50) NOT NULL,
	domicilio_fiscal_cia_aseguradora varchar(100) NULL,
	representante_legal_cia_aseguradora varchar(50) NULL,
	telefono_contacto_cia_aseguradora varchar(30) NULL,
	CONSTRAINT compania_aseguradora_pk PRIMARY KEY (id_cia_aseguradora)
);

CREATE TABLE kc_coches.tipo_poliza (
	id_tipo_poliza serial NOT NULL,
	nombre_tipo_poliza varchar(50) NOT NULL,
	descripcion_tipo_poliza varchar(100) NULL,
	estado_tipo_poliza boolean NULL DEFAULT true,
	CONSTRAINT tipo_poliza_pk PRIMARY KEY (id_tipo_poliza)
);

CREATE TABLE kc_coches.divisa (
	id_divisa serial NOT NULL,
	acronimo_divisa char(3) NOT NULL,
	descripcion_divisa varchar(50) NULL,
	estado_divisa boolean NOT NULL DEFAULT true,
	fecha_creacion_divisa timestamp NOT NULL DEFAULT now(),
	tipo_cambio_a_eur_divisa double precision NOT NULL,
	CONSTRAINT divisa_pk PRIMARY KEY (id_divisa)
);

CREATE TABLE kc_coches.contrato_poliza (
	id_contrato_poliza VARCHAR(10) NOT NULL,
	id_cia_aseguradora integer NOT NULL,
	id_tipo_poliza integer NOT NULL,
	id_divisa integer NOT NULL,
	importe_contrato_poliza double precision NOT NULL,
	fecha_inicio_contrato_poliza timestamp NOT NULL DEFAULT now(),
	fecha_vencimiento_contrato_poliza timestamp NOT NULL,
	auto_renovacion_contrato_poliza boolean NOT NULL DEFAULT true,
	estado_contrato_poliza boolean NOT NULL DEFAULT true,
	CONSTRAINT contrato_poliza_pk PRIMARY KEY (id_contrato_poliza),
	CONSTRAINT contrato_poliza_fk FOREIGN KEY (id_cia_aseguradora) REFERENCES kc_coches.compania_aseguradora(id_cia_aseguradora) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT contrato_poliza_fk_1 FOREIGN KEY (id_tipo_poliza) REFERENCES kc_coches.tipo_poliza(id_tipo_poliza) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT contrato_poliza_fk_2 FOREIGN KEY (id_divisa) REFERENCES kc_coches.divisa(id_divisa) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE kc_coches.grupo (
	id_grupo serial NOT NULL,
	nombre_grupo varchar(30) NOT NULL,
	descripcion_grupo varchar(100) NULL,
	domicilio_fiscal_grupo varchar(50) NOT NULL,
	fecha_creacion_grupo timestamp NOT NULL DEFAULT now(),
	representante_legal_grupo varchar(30) NULL,
	CONSTRAINT grupo_pk PRIMARY KEY (id_grupo)
);

CREATE TABLE kc_coches.marca (
	id_marca serial NOT NULL,
	nombre_marca varchar(20) NOT NULL,
	representante_legal_marca varchar(50) NULL,
	domicilio_fiscal_marca varchar(50) NULL,
	fecha_creacion_marca timestamp NOT NULL DEFAULT now(),
	id_grupo integer NOT NULL,
	CONSTRAINT marca_pk PRIMARY KEY (id_marca),
	CONSTRAINT marca_fk FOREIGN KEY (id_grupo) REFERENCES kc_coches.grupo(id_grupo) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE kc_coches.modelo (
	id_modelo serial NOT NULL,
	nombre_modelo varchar(30) NOT NULL,
	anio_lanzamiento_modelo char(4) NOT NULL,
	estado_modelo boolean NOT NULL DEFAULT true,
	id_marca integer NOT NULL,
	CONSTRAINT modelo_pk PRIMARY KEY (id_modelo),
	CONSTRAINT modelo_fk FOREIGN KEY (id_marca) REFERENCES kc_coches.marca(id_marca) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE kc_coches.color (
	id_color serial NOT NULL,
	nombre_color varchar(30) NOT NULL,
	descripcion_color varchar(50) NULL,
	estado_color boolean NOT NULL DEFAULT true,
	CONSTRAINT color_pk PRIMARY KEY (id_color)
);

CREATE TABLE kc_coches.coche (
	id_matricula_coche varchar(20) NOT NULL,
	km_actual_coche double precision NOT NULL,
	fecha_compra_coche timestamp NOT NULL DEFAULT now(),
	estado_coche boolean NOT NULL DEFAULT true,	
	id_modelo integer NOT NULL,
	id_contrato_poliza VARCHAR(10) NOT NULL, 
	id_color integer NOT NULL, 
	CONSTRAINT matricula_coche_pk PRIMARY KEY (id_matricula_coche),
	CONSTRAINT modelo_fk FOREIGN KEY (id_modelo) REFERENCES kc_coches.modelo(id_modelo) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT contrato_poliza_fk FOREIGN KEY (id_contrato_poliza) REFERENCES kc_coches.contrato_poliza(id_contrato_poliza) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT color_fk FOREIGN KEY (id_color) REFERENCES kc_coches.color(id_color) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE kc_coches.diagnostico_revision (
	id_diagnostico_revision serial NOT NULL,
	nombre_diagnostico_revision varchar(30) NOT NULL,
	descripcion_diagnostico_revision varchar(100) NULL,
	estado_diagnostico_revision boolean NOT NULL DEFAULT true,
	CONSTRAINT diagnostico_revision_pk PRIMARY KEY (id_diagnostico_revision)
);

CREATE TABLE kc_coches.revision (
	id_revision serial NOT NULL,
	mecanico_revision varchar(50) NOT NULL,
	km_revision double precision NOT NULL,
	fecha_revision timestamp NOT NULL DEFAULT now(),
	importe_revision double precision NOT NULL,
	descuento_revision double precision NOT null default 0.,
	observacion_revision varchar(100) NOT NULL,
	estado_revision boolean NOT NULL DEFAULT true,	
	id_divisa integer NOT NULL,
	id_matricula_coche varchar(20) NOT NULL, 
	id_diagnostico_revision integer NOT NULL, 
	CONSTRAINT revision_pk PRIMARY KEY (id_revision),
	CONSTRAINT divisa_fk FOREIGN KEY (id_divisa) REFERENCES kc_coches.divisa(id_divisa) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT matricula_coche_fk FOREIGN KEY (id_matricula_coche) REFERENCES kc_coches.coche(id_matricula_coche) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT diagnostico_revision_fk FOREIGN KEY (id_diagnostico_revision) REFERENCES kc_coches.diagnostico_revision(id_diagnostico_revision) ON DELETE CASCADE ON UPDATE CASCADE
);


--select * from kc_coches.grupo g 

insert into kc_coches.grupo(nombre_grupo, descripcion_grupo, domicilio_fiscal_grupo, representante_legal_grupo) values
('VAN ESPAÑA', 'EL GRUPO VAN', 'ESPAÑA', 'JUAN SALAZAR'),
('CAR GROUP', 'THE CAR GROUP', 'UNITED KINGDOM', 'JAMES SMIDTH'),
('GROUP VOITURE', 'LE GROUP VOITURE', 'FRANCE', 'GERARD FRANÇOIS');

--select * from kc_coches.marca m 

insert into kc_coches.marca (nombre_marca, representante_legal_marca, domicilio_fiscal_marca, id_grupo) values
('VW', 'ADOLF ALEMAN', 'MUNICH', 1),
('SEAT', 'CARLOS SANCHEZ', 'PAMPLONA', 1),
('AUDI', 'RICHARD BOND', 'LONDON', 1),
('TOYOTA', 'HIROITO KAWAMURA', 'TOKIO', 2),
('LEXUS', 'ANDY KIDMAN', 'LIVERPOOL', 2),
('DAIHATSU', 'ROBERTO FELIX', 'LISBOA', 2),
('NISSAN', 'FREDERICH POLONI', 'LYON', 3),
('SANYONG', 'SAMUEL HITO', 'SEUL', 3),
('CHEVROLET', 'CLAUDE HART', 'LIMERICK', 3),
('OPEL', 'BILL SANDERS', 'NEWCASTLE', 3);


--select * from kc_coches.modelo m 

INSERT into kc_coches.modelo (nombre_modelo, anio_lanzamiento_modelo, id_marca) values
('TIGUAN', '2014', 1),
('GOLF', '2003', 1),
('BEETLE', '2000', 1),
('LEON', '1998', 2),
('ATECA', '2016', 2),
('IBIZA', '1999', 2),
('AUDI C1', '2001', 3),
('AUDI C5', '2017', 3),
('AUDI C6', '2015', 3),
('AURIS', '2002', 4),
('CORONA', '1991', 4),
('RAV4', '2015', 4),
('COROLLA', '1989', 4),
('PRIUS', '2004', 4),
('NR3', '2011', 5),
('TERIUS', '1998', 6);

--select * from kc_coches.color c 

insert into kc_coches.color (nombre_color, descripcion_color) values 
('AZUL CIELO', 'METALIZADO'),
('ROJO AZABACHE', 'BRILLANTE'),
('VERDE TENUE', 'LIGERAMENTE OSCURO'),
('NEGRO METALIZADO', 'TONO DEGRADADO'),
('GRIS BRILLANTE', 'BRILLOS'),
('AMARILLO LIGHT', 'SUAVIZADO'),
('ROSA PERLADO', 'BRILLOS');

--select * from kc_coches.compania_aseguradora ca 

insert into kc_coches.compania_aseguradora (nombre_cia_aseguradora, domicilio_fiscal_cia_aseguradora, representante_legal_cia_aseguradora, telefono_contacto_cia_aseguradora) values 
('MUTUA MADRILEÑA MMT', 'MADRID', 'ALEJANDRO SANTOS', '912878587'),
('CASER', 'LOGROÑO', 'JORDI CARTER', '912847656'),
('MAPFRE', 'MADRID', 'ISRAEL GALLEGO', NULL),
('AXA', 'A CORUÑA', 'SANDRA LEDESMA', '912879482'),
('GENESIS', 'VALENCIA', 'CARLOS GARCIA', NULL);

--select * from kc_coches.tipo_poliza tp 

insert into kc_coches.tipo_poliza (nombre_tipo_poliza, descripcion_tipo_poliza) values 
('TODO RIESGO', 'COBERTURA TOTAL'),
('TODO RIESGO CON FRANQUICIA 400', 'LOS PRIMEROS 400 EUROS'),
('TODO RIESGO CON FRANQUICIA 200', 'LOS PRIMEROS 200 EUROS'),
('A TERCEROS CON LUNAS', 'ECONOMICO CON LUNAS'),
('A TERCEROS BASICO', 'SIN LUNAS');

--select * from kc_coches.divisa d 

insert into kc_coches.divisa (acronimo_divisa, descripcion_divisa, tipo_cambio_a_eur_divisa) values 
('EUR', 'EURO', 1),
('GBP', 'LIBRA ESTERLINA', 1.1),
('USD', 'DOLAR AMERICANO', 0.9),
('PEN', 'NUEVO SOL PERU', 0.3),
('JPY', 'YEN JAPON', 0.25);


--select * from kc_coches.contrato_poliza cp 

insert into kc_coches.contrato_poliza (id_contrato_poliza, id_cia_aseguradora, id_tipo_poliza, id_divisa, importe_contrato_poliza, fecha_vencimiento_contrato_poliza) values 
('A003481E0', 1, 1, 1, 865.5, '2024-01-19'),
('969W8W97C', 1, 2, 2, 201, '2024-10-19'),
('I45U645Y7', 1, 3, 3, 530, '2024-09-29'),
('K12G345Y4', 2, 1, 1, 756, '2024-03-19'),
('K4G366DS7', 2, 2, 3, 652.6, '2025-09-13'),
('I34U345WW', 2, 3, 4, 456.1, '2024-09-09'),
('234RF87GI', 3, 4, 1, 219.5, '2026-09-09'),
('KBHJDF324', 3, 5, 2, 289.5, '2024-09-18'),
('KBJ324F4T', 3, 5, 5, 3089.5, '2024-09-09'),
('JH435FJ45', 1, 1, 1, 865.5, '2023-12-09'),
('WGSE234ER', 1, 2, 2, 661, '2024-09-09'),
('DF3GV3543', 1, 3, 3, 500, '2024-09-09'),
('D435TFG23', 2, 1, 1, 756, '2024-09-09'),
('234K56B6J', 2, 2, 3, 652.6, '2024-09-09'),
('8733FF264', 2, 3, 4, 356.1, '2024-09-09'),
('D45EGF464', 3, 4, 1, 119.5, '2024-09-09'),
('4RETG35G4', 3, 5, 2, 289.5, '2024-09-09'),
('DV43D56FG', 3, 5, 5, 289.5, '2025-11-09'),
('DF436R235', 1, 1, 1, 565.5, '2024-09-09'),
('D3246S73F', 1, 2, 2, 701, '2025-05-09'),
('R3453YE7T', 1, 3, 3, 540, '2024-01-09'),
('DF6HGH57X', 2, 1, 1, 756, '2024-09-09'),
('RT4334YW5', 2, 2, 3, 652.6, '2024-09-09'),
('DS3457FUD', 2, 3, 4, 456.1, '2024-09-09'),
('5460034E0', 3, 4, 1, 319.5, '2024-02-09'),
('HG45K6J72', 3, 5, 2, 289.5, '2024-09-09'),
('KBJSDF36V', 3, 5, 5, 3089.5, '2024-03-09');


--select * from kc_coches.diagnostico_revision dr 

insert into kc_coches.diagnostico_revision (nombre_diagnostico_revision, descripcion_diagnostico_revision) values
('APTO 100', 'VEHICULO SIN DESPERFECTO ALGUNO'),
('APTO 50', 'VEHICULO CON DESPERFECTOS NO GRAVE'),
('NO APTO', 'VEHICULO CON DESPERFECTOS GRAVES'),
('SINIESTRADO', 'VEHICULO RECOMENDADO PARA NO CIRCULAR');



--select * delete from kc_coches.coche c 

insert into kc_coches.coche (id_matricula_coche, km_actual_coche, fecha_compra_coche, id_modelo, id_contrato_poliza, id_color) values
('1052BDC', 34986, '2020-01-11', 1, 'A003481E0', 1),
('0967HGM', 200651, '2021-04-15', 2, '969W8W97C', 2),
('4435FGB', 14931, '2020-03-19', 3, 'I45U645Y7', 3),
('6547LMS', 8763, '2022-01-05', 4, 'K12G345Y4', 4),
('8568HTG', 983475, '2023-02-15', 5, 'K4G366DS7', 5),
('0567CFD', 98135, '2019-01-15', 6, 'I34U345WW', 6),
('2865CFF', 18912, '2017-10-14', 7, '234RF87GI', 7),
('6467GHD', 209786, '2019-11-15', 8, 'KBHJDF324', 1),
('5889JYT', 409813, '2021-07-17', 9, 'KBJ324F4T', 2),
('6737JGG', 1021, '2020-01-28', 10, 'JH435FJ45', 3),
('7683BFD', 98154, '2020-06-20', 11, 'WGSE234ER', 4),
('2347DDS', 20923, '2023-01-30', 12, 'DF3GV3543', 5),
('9342DSQ', 109823, '2022-04-17', 13, 'D435TFG23', 6),
('0012QYT', 908713, '2020-01-11', 14, '234K56B6J', 7),
('2465KKM', 90878, '2020-05-15', 15, '8733FF264', 1),
('2354KLM', 10912, '2017-01-12', 1, 'D45EGF464', 2),
('0981BGF', 30486, '2020-07-15', 2, '4RETG35G4', 3),
('1765GBF', 40578, '2016-01-14', 3, 'DV43D56FG', 4),
('9834HMT', 10928, '2021-08-15', 4, 'DF436R235', 5),
('6576HFD', 50938, '2020-01-15', 5, 'D3246S73F', 6),
('8676KJM', 78982, '2022-09-16', 6, 'R3453YE7T', 1),
('1235FDR', 90817, '2016-01-17', 7, 'DF6HGH57X', 2),
('7761KMB', 190923, '2023-02-03', 8, 'RT4334YW5', 3),
('1134NMF', 19876, '2020-01-27', 9, 'DS3457FUD', 4),
('0008LMK', 33028, '2019-01-22', 10, '5460034E0', 5),
('1175HBM', 128761, '2020-08-21', 11, 'HG45K6J72', 6),
('4821HHM', 18735, '2015-04-10', 14, 'KBJSDF36V', 1);


--select * from kc_coches.revision r 

insert into kc_coches.revision (id_matricula_coche, mecanico_revision, km_revision, importe_revision, id_divisa, id_diagnostico_revision, observacion_revision) values 
('1052BDC', 'JUAN PEREZ', 9019, 203.7, 1, 1, 'SISTEMA ELECTRICO Y MECANICO OK'),
('1052BDC', 'SALVADOR SOLAR', 21001, 321.6, 1, 1, 'SISTEMA ELECTRICO Y MECANICO OK- DESGASTE NORMAL RUEDA'),
('1052BDC', 'JUAN PEREZ', 30197, 278.1, 1, 2, 'REEMPLAZO DE LAS BOMBILLAS LED DELANTERAS'),
('0967HGM', 'SALVADOR SOLAR', 19024, 156.7, 2, 1, 'SISTEMA ELECTRICO Y MECANICO OK'),
('0967HGM', 'SALVADOR SOLAR', 51001, 321.6, 2, 1, 'SISTEMA ELECTRICO Y MECANICO OK- DESGASTE NORMAL RUEDA'),
('0967HGM', 'JUAN PEREZ', 80192, 278.1, 2, 2, 'REEMPLAZO DE LOS DISCOS DE FRENOS'),
('0967HGM', 'JUAN PEREZ', 130191, 478.1, 2, 2, 'REEMPLAZO DEL CARBURADOR'),
('0967HGM', 'JUAN PEREZ', 173794, 508.1, 2, 3, 'REEMPLAZO DEL CARTER DE ACEITE'),
('8568HTG', 'CARLOS MARTINEZ', 9019, 303.7, 2, 1, 'SISTEMA ELECTRICO Y MECANICO OK'),
('8568HTG', 'JUAN PEREZ', 24011, 173.8, 2, 1, 'SISTEMA ELECTRICO Y MECANICO OK - BOMBILLAS REEMPLAZADAS'),
('8568HTG', 'CARLOS MARTINEZ', 99019, 245.1, 2, 1, 'SISTEMA ELECTRICO Y MECANICO OK'),
('8568HTG', 'JUAN PEREZ', 190023, 333.3, 2, 2, 'SISTEMA ELECTRICO Y MECANICO OK'),
('8568HTG', 'JUAN PEREZ', 290015, 233, 2, 3, 'RECOMENDABLE PASAR CONSTANTES REVISIONES'),
('8568HTG', 'CARLOS MARTINEZ', 490191, 153.7, 2, 3, 'SISTEMA ELECTRICO EN CONDICIONES ACEPTABLES'),
('8568HTG', 'JUAN PEREZ', 679016, 345.1, 2, 3, 'SISTEMA ELECTRICO Y MECANICO CON REVISIONES CONTINUAS'),
('8568HTG', 'SALVADOR SOLAR', 890190, 303.1, 2, 4, 'SISTEMA MECANICO PENDIENTE DE REVISAR'),
('1175HBM', 'SALVADOR SOLAR', 9019, 443.4, 3, 1, 'SISTEMA ELECTRICO Y MECANICO OK'),
('1175HBM', 'JUAN PEREZ', 23019, 563.2, 3, 2, 'SISTEMA ELECTRICO Y MECANICO OK'),
('1175HBM', 'SALVADOR SOLAR', 4310, 352.7, 3, 3, 'SISTEMA ELECTRICO PENDIENTE DE REVISAR'),
('1175HBM', 'JUAN PEREZ', 10024, 135.2, 3, 4, 'PENDIENTE DE PASAR UNA SEGUNDA REVISIÓN EXHAUSTIVA'),
('1765GBF', 'JUAN PEREZ', 9001, 103.7, 1, 1, 'SISTEMA ELECTRICO Y MECANICO OK'),
('1765GBF', 'SALVADOR SOLAR', 19019, 224.7, 1, 1, 'SISTEMA ELECTRICO Y MECANICO OK'),
('1765GBF', 'JUAN PEREZ', 24065, 453.1, 1, 1, 'SISTEMA ELECTRICO Y MECANICO OK'),
('1765GBF', 'ALBERTO ORTIZ', 29019, 343.7, 1, 1, 'SISTEMA ELECTRICO Y MECANICO OK'),
('1765GBF', 'SALVADOR SOLAR', 39011, 563.1, 1, 1, 'SISTEMA ELECTRICO Y MECANICO OK');
