// const bolas=[10,20,40, 80]

/* CONSTANTS & VARIABLES DEFINITION*/
const diCaprioBorn=1975

const width=1200
const height=900
const margin= {
    top: 80,
    right: 50,    
    bottom: 60,
    left: 50
}

const util = {
    div_2: 2,
    div_3: 3,
    div_4: 4,

    pt_2: 2,
    pt_3: 3,
    pt_4: 4,
    pt_6: 6,
    pt_7: 7,
    pt_10: 10,  
    pt_12: 12
}

// SVG (SELECCIONAMOS EL ID DEL DIV)
const svg=d3.select("div#mainDiv")
                .append("svg")
                    .attr("class", "classSvg")
                    .attr("width", width)
                    .attr("height", height)

// GRUPO - TRANSFORM
const elementGroup=svg.append("g")
                            .attr("class", "elementGroup")
                            .attr("transform", `translate(${margin.left}, ${margin.top})`)

// TITLE
const title=svg.append("text")
                    .attr("class", "title")
                    .attr("font-size", "20px")
                    .attr("font-family", "Neo Sans")                    
                    .text("Leonardo DiCaprio se niega a salir con mujeres mayores de 25 años ¿mito?")
                    .attr("transform", `translate(${(width-margin.left-margin.right-margin.left)/util.div_4}, ${margin.top/util.div_2})`)

// EJES
const axis=svg.append("g")
                    .attr("class", "axis")
const xAxisGroup=axis.append("g")
                        .attr("class", "xAxisGroup")
                        .attr("transform", `translate(${margin.left}, ${height-margin.bottom})`)

const yAxisGroup=axis.append("g")
                        .attr("class", "yAxisGroup")
                        .attr("transform", `translate(${margin.left}, ${margin.top})`)                  
                     
//ESCALA X
const xSc=d3
            //.scaleLinear().range([0, width-margin.left-margin.right]) // BARRA HORIZONTAL + CSV
            //.padding(0.2)  //paddingouter     // BARRA HORIZONTAL
              .scaleBand().range([0, width-margin.left-margin.right])    // BARRA VERTICAL + CSV
              .padding(0.2) 

const ySc=d3
            //.scaleBand().range([0, height-margin.top-margin.bottom])    // BARRA HORIZONTAL + CSV
            .scaleLinear().range([height-margin.top-margin.bottom, 0])  // BARRA VERTICAL + CSV

//const r=d3.scaleLinear()
//                .range([5,10])

// EJES
const xAxis=d3.axisBottom()
                    .scale(xSc)

const yAxis=d3.axisLeft()
                    .scale(ySc)

svg.append("text")
        .attr("x", (width-margin.left-margin.right)/util.div_2 )
        .attr("y", height-(margin.bottom/util.div_3))
        .attr("font-size", "15px")
        .attr("font-family", "Neo Sans")        
        .text("Eje - Evolución por año (edad de las novias de Leo...)");   
        
svg.append("text")
        .attr("transform", "rotate(-90)")        
        .attr("x",-height/util.div_2)                
        .attr("y",margin.left/util.div_3)
        .attr("font-size", "15px")
        .attr("font-family", "Neo Sans")         
        .text("Eje - Edad");        

svg.append("text")      
        .attr("transform", "rotate(-30)")                                                     
        .attr("x", width/util.div_4-margin.left-margin.right)
        .attr("y", (margin.bottom+height)/util.div_2+margin.top)
        .attr("font-size", "15px")
        .attr("font-family", "Neo Sans")
        .text("Edad de Leonardo Dicaprio...")              



//const url="http://localhost:8000/world-cup-winners"

//d3.json(url)    // LECTURA CSV / URL
d3.csv("dataLD.csv")    // LECTURA DE UN CSV
.then(data=>{ 
    //data=d3.entries(data)   

    data.forEach(row=>{
        //row.titles=+row.titles  // CSV
        //row.value=+row.value  // URL
        row.year=+row.year
        row.age=+row.age
        row["LeoAge"]=row.year-diCaprioBorn
    })

    console.log(data)

    //xSc.domain([0,d3.max(data.map(row=>row.titles))]) // BARRA HORIZONTAL + CSV
    //ySc.domain(data.map(row=>row.country)) // BARRA HORIZONTAL + CSV
    //xSc.domain(data.map(row=>row.country)) // BARRA VERTICAL + CSV
    //ySc.domain([0,d3.max(data.map(row=>row.titles))]) // BARRA VERTICAL + CSV
    //xSc.domain(data.map(row=>row.key)) // BARRA VERTICAL + JSON
    //ySc.domain([0,d3.max(data.map(row=>row.value))]) // BARRA VERTICAL + JSON
    xSc.domain(data.map(row=>row.year)) // BARRA VERTICAL + CSV    
    //ySc.domain([d3.min(data.map(row=>row.age)),d3.max(data.map(row=>row.age))]) // BARRA VERTICAL + CSV
    ySc.domain([d3.min(data.map(row=>row.age))-2, d3.max(data.map(row=>row.LeoAge))])

    //xAxis.ticks(d3.max(data.map(row=>row.titles)))  // BARRA HORIZONTAL
    //yAxis.ticks(d3.max(data.map(row=>row.titles)))  // BARRA VERTICAL
    //yAxis.ticks(d3.max(data.map(row=>row.value)))  // BARRA VERTICAL + JSON
    yAxis.ticks(d3.max(data.map(row=>row.age)))  // BARRA VERTICAL

    // SHOW AXIS
    xAxisGroup.call(xAxis)
    yAxisGroup.call(yAxis)

    // PATRON DE ACTUALIZACION - DATA BINDING
    const elementDataBinding = elementGroup.selectAll("rect").data(data)
    elementDataBinding.enter()                        
                        .append("rect")                        
                            //.attr("class", row=>row.country)    // CSV
                            .attr("class", row=>row.name)  // URL
                            .attr("x", row=>xSc(row.year))
                            .attr("y", row=>ySc(row.age))
                            .attr("width", xSc.bandwidth())
                            .attr("height", row=>height-margin.top-margin.bottom-ySc(row.age))     

    elementDataBinding.enter()                        
                            .append("text")                                                       
                            .attr("x", row=>xSc(row.year)+xSc.bandwidth()/util.div_3)
                            .attr("y", row=>ySc(row.age)-util.pt_2)
                            .attr("font-size", "13px")
                            .attr("font-family", "Neo Sans")
                            .text(row=>row.age)

    elementDataBinding.enter()                        
                            .append("text")                                                       
                            .attr("x", row=>xSc(row.year)+util.pt_6)
                            .attr("y", row=>ySc(row.age)+util.pt_12)
                            .attr("font-size", "9px")
                            .attr("font-family", "Neo Sans")
                            .text(row=>row.name.split(" ")[0])

                            /* BARRA HORIZONTAL + CSV
                            .attr("x", 0)
                            .attr("y", row=>ySc(row.country))
                            .attr("width", row=>xSc(row.titles))
                            .attr("height", ySc.bandwidth())
                            */

                            /* BARRA VERTICAL + CSV
                            .attr("x", row=>xSc(row.country))
                            .attr("y", row=>ySc(row.titles))
                            .attr("width", xSc.bandwidth())
                            .attr("height", row=>height-margin.top-margin.bottom-ySc(row.titles))
                            */

                            /* JSON 
                            .attr("x", row=>xSc(row.key))
                            .attr("y", row=>ySc(row.value))
                            .attr("width", xSc.bandwidth())
                            .attr("height", row=>height-margin.top-margin.bottom-ySc(row.value))
                            */                            


    /* LEONARDO DICAPRIO AGE - DIAGONAL LINE */
    elementDataBinding.enter()                        
                            .append("circle")                                                       
                            .attr("cx", row=>xSc(row.year)+xSc.bandwidth()/util.div_2)
                            .attr("cy", row=>ySc(row.LeoAge))
                            .attr("r", util.pt_7)
    elementDataBinding.enter()                        
                            .append("circle")                                                       
                            .attr("class", "concentric")
                            .attr("cx", row=>xSc(row.year)+xSc.bandwidth()/util.div_2)
                            .attr("cy", row=>ySc(row.LeoAge))
                            .attr("r", util.pt_4)                                                        
    elementDataBinding.enter()                        
                            .append("text")                                                       
                            .attr("x", row=>xSc(row.year)+util.pt_10)
                            .attr("y", row=>ySc(row.LeoAge)-util.pt_10)
                            .attr("font-size", "13px")
                            .attr("font-family", "Neo Sans")
                            .text(row=>row.LeoAge) 
                      
    elementGroup.datum(data)
                    .append("path")
                    .attr("id", "linea")
                    .attr("d", d3.line()
                    .x(d=>xSc(d.year)+xSc.bandwidth()/util.div_2)
                    .y(d=>ySc(d.LeoAge)))

    /*
    data.map((row, index)=>{   
        elementGroup.append("circle")
                        .attr("class", row.country)
                        .attr("cx", xSc(row.titles))
                        .attr("cy", 100)
                        .attr("r", 10*row.titles)                        
    })
    */                    

})



                        