CREATE OR REPLACE FUNCTION `keepcoding.clean_integer`(intValue INT64)
RETURNS INT64
AS 
(
  IFNULL(intValue, -999999)
);


----------------TESTING------------------
--SELECT `keepcoding.clean_integer`(123)
--SELECT `keepcoding.clean_integer`(NULL)
-----------------------------------------