---------------------------------------------------------------------------------
--EJERCICIO 01 -------------- 21674 LLAMADAS --------- REGISTROS UNICOS----------
--SE HA COMPROBADO EL ivr_id ES UNICO, DE LA MISMA MANERA, LAS FILAS SON UNICAS--
--SE PREPARA ALGUNOS CAMPOS CON UPPER/TRIM PARA SU USO EN SUMMARY----------------
--SE CREA LA TABLA: ivr_detail---------------------------------------------------
---------------------------------------------------------------------------------
CREATE OR REPLACE TABLE `keepcoding.ivr_detail` AS
SELECT 
  calls.ivr_id,
  calls.phone_number,
  calls.ivr_result,
  UPPER(TRIM(calls.vdn_label)) AS vdn_label,
  calls.start_date,
  FORMAT_DATE('%Y%m%d', calls.start_date) AS calls_start_date_id,
  calls.end_date,
  FORMAT_DATE('%Y%m%d', calls.end_date) AS calls_end_date_id,
  calls.total_duration,
  calls.customer_segment,
  calls.ivr_language,
  calls.steps_module,
  calls.module_aggregation,
  modules.module_sequece,
  UPPER(TRIM(modules.module_name)) AS module_name,
  modules.module_duration,
  modules.module_result,
  steps.step_sequence,
  UPPER(TRIM(steps.step_name)) AS step_name,
  steps.step_result,
  UPPER(TRIM(steps.step_description_error)) AS step_description_error,
  steps.document_type,
  steps.document_identification,
  steps.customer_phone,
  steps.billing_account_id
FROM `keepcoding.ivr_calls` AS calls
LEFT OUTER JOIN `keepcoding.ivr_modules` AS modules
ON calls.ivr_id = modules.ivr_id
LEFT OUTER JOIN `keepcoding.ivr_steps` AS steps
ON modules.ivr_id = steps.ivr_id
AND modules.module_sequece = steps.module_sequece;


---------------------------------------------------------------------------------
--EJERCICIO 02 - NUMERO DE REGISTROS 21674 -- SE AGRUPAN LAS LLAMADAS -----------
--AL AGRUPAR-SE EXTRAE EL VALOR SOLICITADO SEGÚN LA CONDICIÓN ESTABLECIDA--------
--LOS NOMBRES DE CAMPOS QUE EMPIEZA CON: check_ (SIRVE PARA COMPROBACIÓN)--------
--SE CREA LA TABLA SUMMARY-------------------------------------------------------
---------------------------------------------------------------------------------
CREATE OR REPLACE TABLE `keepcoding.ivr_summary` AS
SELECT
    detail.ivr_id,
    detail.phone_number,
    detail.ivr_result,
    (
        CASE 
            WHEN STARTS_WITH(detail.vdn_label, 'ATC') THEN 
              'FRONT'
            WHEN STARTS_WITH(detail.vdn_label, 'TECH') THEN 
              'TECH'
            WHEN STARTS_WITH(detail.vdn_label, 'ABSORPTION') THEN 
              'ABSORPTION'
            ELSE 
              'RESTO'
        END
    ) AS vdn_aggregation,
    detail.total_duration,
    detail.customer_segment,
    detail.ivr_language,
    detail.steps_module,
    detail.module_aggregation,

    STRING_AGG(DISTINCT NULLIF(detail.document_type, 'NULL'), '\n') AS document_type,
    STRING_AGG(DISTINCT NULLIF(detail.document_identification, 'NULL'), '\n') AS document_identification, 
    STRING_AGG(DISTINCT NULLIF(detail.customer_phone, 'NULL'), '\n') AS customer_phone,
    STRING_AGG(DISTINCT NULLIF(detail.billing_account_id, 'NULL'), '\n') AS billing_account_id,
    STRING_AGG(DISTINCT NULLIF(detail.module_name, 'NULL'), '\n') AS module_name,
    MAX(IF(detail.module_name='AVERIA_MASIVA', 1, 0)) AS masiva_lg,

    --CHECK EL CALCULO DE LOS CAMPOS: step_name Y step_description (SE AÑADE EL SEPARADOR # ENTRE LOS CAMPOS)
    STRING_AGG(DISTINCT CONCAT(detail.step_name, '#', detail.step_description_error), '\n') AS check_step_name,
    MAX(IF(CONCAT(detail.step_name, '#',detail.step_description_error)='CUSTOMERINFOBYPHONE.TX#NULL', 1, 0)) AS info_by_phone_lg,
    MAX(IF(CONCAT(detail.step_name, '#',detail.step_description_error)='CUSTOMERINFOBYDNI.TX#NULL', 1, 0)) AS info_by_dni_lg,
    
    --CHECK (COMBINACIONES DEL ID DE LLAMADA DE DETAIL CON LAS OTRAS LLAMADAS DEL MISMO PHONE_NUMBER)
    COUNT(*) AS check_count,
    --LISTA DE IDS DE LLAMADAS QUE SE RELACIONAN CON IVR_ID DE LA FILA (CON EL MISMO PHONE_NUMBER)-NO APARECERA EL ID DE LA FILA EN LA LISTA (SE EXCLUYE EN EL LEFT JOIN)
    STRING_AGG(DISTINCT CAST(ivr_calls.ivr_id AS STRING), '\n') AS check_ivr_calls_id,

    --LISTA DE END_DATE DE LA LISTA DE LLAMADAS QUE SE RELACIONAN CON EL ID DE LA FILA
    STRING_AGG(DISTINCT CAST(ivr_calls.end_date AS STRING), '\n') AS check_ivr_calls_end_date,
    --EL START_DATE DEL ID DE LA LLAMADA DE LA FILA
    detail.start_date,    
    --COMPARAMOS EL START_DATE DE LA LLAMADA DE LA FILA CON ALGUNA DE LOS END_DATE DE LA LISTA DE LLAMADAS QUE SE RELACIONAN (CALCULAR SI HA HABIDO UNA LLAMADA EN LAS 24 HORAS ANTERIORES)
    --PREVIAMENTE COMPARAMOS QUE EL START_DATE DE LA LLAMADA DE LA FILA DEBE SER MAYOR QUE EL END_DATE DE LA LISTA DE LLAMADAS
    --24 HORAS = 86400 SEGUNDOS--SE ESTABLECE LA DIFERENCIA EN SEGUNDOS PARA UNA MEJOR PRECISION DE LOS CALCULOS
    MAX(IF((detail.start_date > ivr_calls.end_date) AND (DATE_DIFF(detail.start_date, ivr_calls.end_date, SECOND) > 0) AND (DATE_DIFF(detail.start_date, ivr_calls.end_date, SECOND)<=86400), 1, 0)) AS repeated_phone_24H,

    --EL END_DATE DEL ID DE LA LLAMADA DE LA FILA
    detail.end_date,
    --LISTA DE START_DATE DE LA LISTA DE LLAMADAS QUE SE RELACIONAN CON EL ID DE LA FILA
    STRING_AGG(DISTINCT CAST(ivr_calls.start_date AS STRING), '\n') AS check_ivr_calls_start_date,
    --COMPARAMOS EL END_DATE DE LA LLAMADA DE LA FILA CON ALGUNA DE LOS START_DATE DE LA LISTA DE LLAMADAS QUE SE RELACIONAN (CALCULAR SI HA HABIDO UNA LLAMADA EN LAS 24 HORAS POSTERIORES)
    --PREVIAMENTE COMPARAMOS QUE EL START_DATE DE LA LISTA DE LLAMADAS DEBE SER MENOR QUE EL START_DATE DEL ID DE LA LLAMADA DE LA FILA
    --24 HORAS = 86400 SEGUNDOS--SE ESTABLECE LA DIFERENCIA EN SEGUNDOS PARA UNA MEJOR PRECISION DE LOS CALCULOS
    MAX(IF((detail.end_date < ivr_calls.start_date) AND (DATE_DIFF(detail.end_date, ivr_calls.start_date, SECOND) < 0) AND (DATE_DIFF(detail.end_date, ivr_calls.start_date, SECOND)>=-86400), 1, 0)) AS cause_recall_phone_24H

FROM `keepcoding.ivr_detail` AS detail
LEFT OUTER JOIN `keepcoding.ivr_calls` AS ivr_calls
ON detail.phone_number = ivr_calls.phone_number
AND detail.ivr_id <> ivr_calls.ivr_id
GROUP BY 
    detail.ivr_id,
    detail.phone_number,
    detail.ivr_result,
    detail.vdn_label,
    detail.start_date,
    detail.end_date,
    detail.total_duration,
    detail.customer_segment,
    detail.ivr_language,
    detail.steps_module,
    detail.module_aggregation;

  
  --CONSULTANDO LA TABLA SUMMARY
  SELECT 
    *
  FROM `keepcoding.ivr_summary`;