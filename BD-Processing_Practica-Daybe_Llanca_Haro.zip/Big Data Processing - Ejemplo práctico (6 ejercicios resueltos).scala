// Databricks notebook source
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.expressions.Window

lazy val sc=spark.sparkContext

// CONFIGURATIONS //

// TO FILES
lazy val file_name_other = "dbfs:/FileStore/practica/world_happiness_report.csv"
lazy val file_name_2021 = "dbfs:/FileStore/practica/world_happiness_report_2021.csv"

// TO PARAMETERS FILES
lazy val header = "header"
lazy val separator = "separator"

lazy val true_value=true
lazy val separator_value="|"
lazy val unknown_value="unknown"
lazy val max_value="max_value"
lazy val tbd_value="TBD"
lazy val _2021_year=2021
lazy val _2020_year=2020

// COLUMN NAME DEFINITION
lazy val ladderScoreColumn="Ladder score"
lazy val lifeLadderColumn="Life Ladder"
lazy val countryNameColumn="Country name"
lazy val regionalIndicatorColumn="Regional indicator"
lazy val continentColumn="Continent"
lazy val happyRankingColumn="happy_ranking"
lazy val yearColumn="year"
lazy val logGDPPerCapitaColumn="Log GDP per capita"
lazy val loggedGDPPerCapitaColumn="Logged GDP per capita"
lazy val healthyLifeExpectancyAtBirthColumn="Healthy life expectancy at birth"
lazy val healthyLifeExpectancyColumn="Healthy life expectancy"

// COMMAND ----------

// DATAFRAMES DEFINITION FROM CSV FILES

// LEEMOS EL FICHERO CSV DEL 2021 Y SÓLO EXTRAEMOS LOS CAMPOS QUE NOS INTERESA
lazy val dfCsv2021_raw=spark.read.option(header, true_value).option(separator, separator_value).csv(file_name_2021)
                                                              .select(countryNameColumn, regionalIndicatorColumn, ladderScoreColumn, loggedGDPPerCapitaColumn, healthyLifeExpectancyColumn)
                                                              .withColumn(yearColumn, lit(_2021_year))

// UNIFICAMOS Y ESTANDARIZAMOS LOS NOMBRES DE LOS CONTIENENTES
val dfCsv2021=dfCsv2021_raw.withColumn(continentColumn, 
                                 when(col(regionalIndicatorColumn)==="South Asia" || col(regionalIndicatorColumn)==="East Asia", "Asia")
                                .when(col(regionalIndicatorColumn)==="Middle East and North Africa" || col(regionalIndicatorColumn)==="Sub-Saharan Africa" || col(regionalIndicatorColumn)==="Southeast Asia", "Africa")
                                .when(col(regionalIndicatorColumn)==="North America and ANZ" || col(regionalIndicatorColumn)==="Latin America and Caribbean", "America")
                                .when(col(regionalIndicatorColumn)==="Western Europe" || col(regionalIndicatorColumn)==="Central and Eastern Europe" || col(regionalIndicatorColumn)==="Commonwealth of Independent States", "Europa")
                                .otherwise(unknown_value))
                            .drop(col(regionalIndicatorColumn))

// dfCsv2021.show
// dfCsv2021.printSchema
display(dfCsv2021)

// COMMAND ----------

// DATAFRAMES DEFINITION FROM CSV FILES
lazy val dfCsvOther_raw=spark.read.option(header, true_value).option(separator, separator_value).csv(file_name_other)
                                                                            .select(countryNameColumn, lifeLadderColumn, logGDPPerCapitaColumn, healthyLifeExpectancyAtBirthColumn, yearColumn)

// LECTURA DEL FICHERO CSV (RESTO DE AÑOS), PERO QUE NO TIENE EL CAMPO CONTINENTE PERO LO CALCULAMOS A PARTIR DEL PAIS DEL FICHERO CSV 2021 (MANTENEMOS LA MISMA ESTRUCTURA EN AMBOS FICHEROS)
lazy val dfCsvOther=dfCsvOther_raw.as("df1").join(dfCsv2021.select(col(countryNameColumn), col(continentColumn)).as("df2"), col("df1.Country name")===col("df2.Country name"), "left_outer").drop(col("df2.Country name"))

// dfCsvOther.show
// dfCsvOther.printSchema
 display(dfCsvOther)
// dfCsvOther.count


// COMMAND ----------

// 1. ¿Cuál es el país más “feliz” del 2021 según la data? (considerar que la columna “Ladder score” mayor número más feliz es el país)
val dfResult=dfCsv2021.sort(col(ladderScoreColumn).desc)
                          .select(countryNameColumn, ladderScoreColumn).limit(1)
display(dfResult)

// COMMAND ----------

// 2. ¿Cuál es el país más “feliz” del 2021 por continente según la data?
lazy val dfHappyForContinent=dfCsv2021.groupBy(continentColumn).agg(max(col(ladderScoreColumn)).alias(max_value))

lazy val dfResult=dfCsv2021.as("df1").join(dfHappyForContinent.as("df2"), col("df1.Continent")===col("df2.Continent") && col(ladderScoreColumn)===col("max_value"))
                                                                                                  .select(col("df1.Continent"), col("df1.Country name"), col("df2.max_value"))
display(dfResult)

// COMMAND ----------

// 3. ¿Cuál es el país que más veces ocupó el primer lugar en todos los años?

//  UNION DATASETS
lazy val dfUnionAllYear=dfCsvOther.union(dfCsv2021)
// dfCsvOther.printSchema
// dfCsv2021.printSchema

// COUNTRIES -> PLACED THE FIRST POSITION PER YEAR
lazy val dfMaxPerYear=dfUnionAllYear.groupBy(yearColumn).agg(max(lifeLadderColumn).alias(max_value)).as("df1")
                                                            .join(dfUnionAllYear.as("df2"), col("df1.year")===col("df2.year") && col("df1.max_value")===col("df2.Life Ladder"))
                                                            .select("df1.year", "df2.Country name", "df1.max_value")

lazy val dfCountryTimes=dfMaxPerYear.groupBy(countryNameColumn).agg(count(countryNameColumn).alias("timesNumber"))
lazy val max_times_number=dfCountryTimes.agg(max("timesNumber")).head().get(0)
// println(max_val)
display(dfCountryTimes.filter(col("timesNumber")===max_times_number))

// COMMAND ----------

// 4. ¿Qué puesto de Felicidad tiene el país con mayor GDP del 2020?
lazy val row_num=Window.partitionBy(col(yearColumn)).orderBy(col(lifeLadderColumn).desc)
lazy val dfSortRankingLadder=dfCsvOther.filter(col(yearColumn)===_2020_year).withColumn(happyRankingColumn, row_number.over(row_num))
lazy val maxValueGDP2020=dfSortRankingLadder.agg(max(col(logGDPPerCapitaColumn))).head().get(0)

display(dfSortRankingLadder.filter(col(logGDPPerCapitaColumn)===maxValueGDP2020).select(yearColumn, countryNameColumn, lifeLadderColumn, logGDPPerCapitaColumn, happyRankingColumn))
// dfSortRankingLadder.show

// COMMAND ----------

// 5. ¿En que porcentaje a variado a nivel mundial el GDP promedio del 2020 respecto al 2021? ¿Aumentó o disminuyó?
lazy val gdpAvg2020_2021=dfUnionAllYear.filter(col(yearColumn)===_2020_year || col(yearColumn)===_2021_year).groupBy(col(yearColumn)).agg(avg(col(logGDPPerCapitaColumn).cast(DoubleType)).alias("gdp_avg"))
lazy val gdpAvg2021=gdpAvg2020_2021.filter(col(yearColumn)===_2021_year).head().get(1)
lazy val dfResult=gdpAvg2020_2021.withColumn("GDP Avg 2021 Reference", lit(gdpAvg2021)).withColumn("% (+/-)", (col("gdp_avg")*100/gdpAvg2021)-100)

display(dfResult)

// COMMAND ----------

// 6. ¿Cuál es el país con mayor expectativa de vide (“Healthy life expectancy at birth”)? Y ¿Cuánto tenia en ese indicador en el 2019?
display(dfUnionAllYear.sort(col(healthyLifeExpectancyAtBirthColumn).desc).select(col(countryNameColumn), col(healthyLifeExpectancyAtBirthColumn), col(yearColumn)).limit(1))
