AUTOR: DAYBE LLANCA HARO

CONTENIDO:
---------
1.- Fichero .scala (Big Data Processing - Ejemplo práctico (6 ejercicios resueltos).scala)
    Para su ejecución, los data sets deberán estar en una carpeta "practica" DBFS (como a continuación):
	"dbfs:/FileStore/practica/world_happiness_report.csv"
	"dbfs:/FileStore/practica/world_happiness_report_2021.csv"

2.- PUBLICACIÓN MEDIUM (https://medium.com/@linux80/101-procesamiento-distribuido-de-grandes-vol%C3%BAmenes-de-datos-ejemplo-pr%C3%A1ctico-77152114879e)

FECHA: 12.11.2023